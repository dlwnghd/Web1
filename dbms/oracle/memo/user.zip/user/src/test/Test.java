package test;

import dao.UserDAO;
import vo.UserVO;

public class Test {
	public static void main(String[] args) {
		//모든 메소드 테스트하기(버그 검사)
	}
}
