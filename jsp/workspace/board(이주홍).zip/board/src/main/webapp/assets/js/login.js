/**
 * 
 */

function send(){
	loginForm.submit();
} 