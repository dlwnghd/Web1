/**
 * 
 */

function send(){
	loginForm.submit();
}