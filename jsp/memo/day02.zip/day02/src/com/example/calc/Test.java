package com.example.calc;

public class Test {
	public static void main(String[] args) {
		int data = Integer.parseInt("-1");
		System.out.println(data + 9);
	}
}
