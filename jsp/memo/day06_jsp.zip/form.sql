create database form;
use form;

create table tbl_member(
	member_number int unsigned auto_increment primary key,
	member_id varchar(1000),
	member_name varchar(500),
	member_pw varchar(1000),
	member_gender char(3),
	member_address varchar(2000),
	member_address_detail varchar(2000)
);

select * from tbl_member;

