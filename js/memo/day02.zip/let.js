var data = 10;
var data = 20;
console.log(data);

let num = 10;
// let num = 20;
num = 20;
console.log(num);

for(let i=0; i<10; i++){

}

// console.log(i);

if(10 > 1){
    let l = 10;
}

console.log(l);