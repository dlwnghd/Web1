const data = 10;
// data = 20;
console.log(data);