/* 
    author: Han
    contents: mouse event
*/

function over(img){
    img.src = "img/crazy.png";
}

function out(img){
    img.src = "img/normal.png"
}