console.log("32" == 32);
console.log("32" === 32);

console.log(parseInt("한동석"));