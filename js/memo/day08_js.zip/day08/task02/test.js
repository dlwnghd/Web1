let test = "0.9";
console.log(test < 1);