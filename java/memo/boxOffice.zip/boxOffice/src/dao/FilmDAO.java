package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

import vo.FilmVO;

public class FilmDAO {
	
	//마지막 순위
	public int getLastRanking() throws IOException{
		BufferedReader br = DBConnecter.getReader();
		int lastRanking = 0;
		while(br.readLine() != null) {
			lastRanking ++;
		}
		
		return lastRanking;
	}
	
	//추가와 삽입
	public void appendAndInsert(FilmVO film) throws IOException{
		if(film.getRanking() != 0) {
			insert(film);
			return;
		}
		append(film);
	}
	
	//추가
	//마지막에 영화를 추가하기 때문에 영화 순위는 전달받지 않는다.
	private void append(FilmVO film) throws IOException{
		BufferedReader br = DBConnecter.getReader();
		int lastRanking = 0;
		String data = null;
		String content = null;
		
		while(br.readLine() != null) {
			lastRanking ++;
		}
		br.close();
		
		//전체 내용을 문자열로 가져온다.
		content = new String(Files.readAllBytes(Paths.get(DBConnecter.getPath())));
		
		//전체 내용 중 가장 마지막 문자가 \n인지 검사한다.
		//만약 마지막에 \n이 없다면 data에 \n부터 추가해준다.
		data = content.charAt(content.length() - 1) == '\n' ?  "" : "\n";
		
		//순위를 제외한 나머지 정보 앞에 계산한 마지막 순위를 연결해준다.
		data += lastRanking + 1 + film.toString().substring(film.toString().indexOf("\t"));
		
		BufferedWriter bw = DBConnecter.getAppend();
		bw.write(data);
		bw.close();
	}
	
	//삽입
	private void insert(FilmVO film) throws IOException{
		BufferedReader br = DBConnecter.getReader();
		String line = null;
		String temp = "";
		int newRanking = film.getRanking();
		boolean check = false;
		
		while((line = br.readLine()) != null) {
			//삽입할 순위 검색
			if(Integer.parseInt(line.split("\t")[0]) == film.getRanking()) {
				//삽입
				temp += film.toString() + "\n";
				check = true;
			}
			
			//삽입되었다면 순위 변경
			// - 기존 랭킹을 전위형으로 1씩 증가시키기 때문에 기존순위 + 1로 변경된다. 
			
			//삽입이 안되었다면 순위 유지
			temp += check ? ++newRanking +  line.substring(line.indexOf("\t")): line;
			temp += "\n";
		}
		br.close();
		
		BufferedWriter bw = DBConnecter.getWriter();
		bw.write(temp);
		bw.close();
	}
	
	//수정
	//영화 제목만 수정이 가능하다고 가정한다.
	//영화 제목에 중복이 있을 수 있기 때문에, 영화 순위끼리 비교하여 정확한 수정을 유도한다.
	//외부에서 수정한 영화의 전체 정보를 받는다.
	public void update(FilmVO film) throws IOException{
		BufferedReader br = DBConnecter.getReader();
		String line = null;
		String temp = "";
		
		while((line = br.readLine()) != null) {
			if(Integer.parseInt(line.split("\t")[0]) == film.getRanking()) {
				temp += film.toString() + "\n";
				continue;
			}
			temp += line + "\n";
		}
		br.close();
		
		BufferedWriter bw = DBConnecter.getWriter();
		bw.write(temp);
		bw.close();
	}
	
	//삭제
	//외부에서 삭제할 영화의 순위를 전달받는다.
	//영화가 삭제되면 아래의 영화 순위들이 위로 하나씩 올라와야 한다.
	public void delete(int ranking) throws IOException {
		BufferedReader br = DBConnecter.getReader();
		String line = null;
		String temp = "";
		boolean check = false;
		int deletedRanking = ranking;
		
		while((line = br.readLine()) != null) {
			if(Integer.parseInt(line.split("\t")[0]) == ranking){
				check = true;
				continue;
			}
			temp += check ?  deletedRanking++ + line.substring(line.indexOf("\t")) : line;
			temp += "\n";
		}
		br.close();
		
		BufferedWriter bw = DBConnecter.getWriter();
		bw.write(temp);
		bw.close();
	}
	
	//검색
	//영화 제목으로 조회
	//사용자가 입력한 키워드가 제목에 포함되어 있어도 결과에 담아준다.
	//"아" 검색 시 "아바타"도 검색 결과에 포함
	//외부에서 사용자가 검색하고자 하는 키워드를 전달받는다.
	//검색 결과는 한 개가 아니라 여러 개이므로 ArrayList에 담아서 리턴한다.
	public ArrayList<FilmVO> selectFilm(String keyword) throws IOException {
		BufferedReader br = DBConnecter.getReader();
		String line = null;
		FilmVO film = null;
		ArrayList<FilmVO> films = new ArrayList<>();
		
		while((line = br.readLine()) != null) {
			String[] filmDatas = line.split("\t");
			
			if(filmDatas[1].contains(keyword)) {
				film = new FilmVO();
				
				film.setRanking(Integer.parseInt(filmDatas[0]));
				film.setName(filmDatas[1]);
				film.setReleaseDate(filmDatas[2]);
				film.setIncome(Long.parseLong(removeComma(filmDatas[3].equals("") ? "0" : filmDatas[3])));
				film.setAudience(Integer.parseInt(removeS(removeComma(filmDatas[4]))));
				film.setScreenCount(Integer.parseInt(removeS(removeComma(filmDatas[5]))));
				
				films.add(film);
			}
		}
		br.close();
		
		return films;
	}
	
	//목록
	//전체 정보 리턴
	public ArrayList<FilmVO> selectAll() throws IOException {
		BufferedReader br = DBConnecter.getReader();
		String line = null;
		FilmVO film = null;
		ArrayList<FilmVO> films = new ArrayList<>();
		
		while((line = br.readLine()) != null) {
			String[] filmDatas = line.split("\t");
			
			film = new FilmVO();
			
			film.setRanking(Integer.parseInt(filmDatas[0]));
			film.setName(filmDatas[1]);
			film.setReleaseDate(filmDatas[2]);
			film.setIncome(Long.parseLong(removeComma(filmDatas[3].equals("") ? "0" : filmDatas[3])));
			film.setAudience(Integer.parseInt(removeS(removeComma(filmDatas[4]))));
			film.setScreenCount(Integer.parseInt(removeS(removeComma(filmDatas[5]))));
			
			films.add(film);
		}
		br.close();
		
		return films;
	}
	
	
	//콤마 지우기
	public String removeComma(String data) {
		return data.replaceAll(",", "");
	}
	
	//S  지우기
	public String removeS(String data) {
		return data.replaceAll("S ", "");
	}
}
























