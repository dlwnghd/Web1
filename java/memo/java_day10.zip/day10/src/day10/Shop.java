package day10;

import java.util.Scanner;

// [심화 실습]
// 시동을 켤 때, 비밀번호 4자리 입력받는다.
// 비밀번호가 일치하면 시동 켜짐
// 비밀번호가 일치하지 않으면 현재 몇 회 연속 틀렸는 지를 출력
// 3회 연속 틀릴 시, "경찰 출동" 출력

class Car{
//브랜드, 색상, 가격
//필요하다면 추가로 더 선언해도 된다.
	String brand;
	String color;
	int price;
	boolean check;
	String pw = "0000";
	int policeCount;
	
	public Car() {;}
	
	public Car(String brand, String color, int price) {
		this.brand = brand;
		this.color = color;
		this.price = price;
	}
	

	public Car(String brand, String color, int price, String pw) {
		this.brand = brand;
		this.color = color;
		this.price = price;
		this.pw = pw;
	}

//비밀번호 검사
	boolean checkPw(String pw) {
		//문자열 끼리 비교할 때에는 equals()를 사용한다.
		//"문자열".equals("문자열")
		return this.pw.equals(pw);
	}
	
//시동 켜기
//시동 켜짐을 출력
//이미 시동이 켜져 있다면, 알맞는 메세지 출력
	boolean engineStart() {
		if(!check) {//시동이 꺼져있을 때
			return true;
		}
		return false;
	}
	
//시동 끄기
//시동 꺼짐을 출력
//이미 시동이 꺼져 있다면, 알맞는 메세지 출력
	boolean engineStop() {
		if(check) {//시동이 꺼져있을 때
			return true;
		}
		return false;
	}
	
}

public class Shop {
	
	public static void main(String[] args) {
		//1. 시동켜기
		//2. 시동끄기
		Car benz = new Car("Benz", "Black", 35000);
		String msg = "1. 시동켜기\n2. 시동끄기";
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		String pw = null;
		
		while(true) {
			System.out.println(msg);
			choice = sc.nextInt();
			
			if(choice == 1) {
				if(benz.engineStart()) {
					
					System.out.print("비밀번호 : ");
					pw = sc.next();
					
					if(benz.checkPw(pw)) {
						System.out.println(benz.brand + " 시동 켜짐");
						benz.policeCount = 0;
						benz.check = true;
					}else {
						benz.policeCount++;
						
						if(benz.policeCount == 3) {
							System.out.println("경찰 출동");
							break;
						}
						
						System.out.println("현재 " + benz.policeCount + "번 비밀번호 오류");
						
					}
				}else {
					System.out.println(benz.brand + "는 이미 시동이 켜져있습니다.");
				}
			}else if (choice == 2){
				if(benz.engineStop()) {
					System.out.println(benz.brand + " 시동 꺼짐");
					benz.check = false;
					
				}else {
					System.out.println(benz.brand + "는 이미 시동이 꺼져있습니다.");
					break;
				}
				
			}else {
				break;
			}
		}
	}
}



















