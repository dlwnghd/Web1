package day10;

import java.util.Random;
import java.util.Scanner;

public class Zoo {
	public static void main(String[] args) {
		Animal[] animals = new Animal[3];
		
		animals[0] = new Animal("기린", 10, "풀", 5, 5);
		animals[1] = new Animal("거북이", 15, "해초", 8, 2);
		animals[2] = new Animal("여우", 3, "고기", 4, 6);
		
		Quiz[] quiz = {
				new Quiz("Q. 다음 중 프로그래밍 언어가 아닌 것은?\n1.JAVA\n2.C언어\n3.파이썬\n4.망둥어", 4, 2),
				new Quiz("Q. JAVA에 없는 챕터는?\n1.변수\n2.클래스\n3.메소드\n4.포인터", 4, 100, true),
				new Quiz("Q. 다음 중 JAVA 기본 자료형이 아닌 것은?\n1.int\n2.boolean\n3.char\n4.String", 4, 50, true)
		};
		
		Scanner sc = new Scanner(System.in);
		
		String title = "★놀러와요 동물 천국★";
		String menuMsg = "안녕하세요! 캐릭터를 선택해봐요~";
		String actionMsg = "1. 먹기\n2. 잠자기\n3. 산책하기\n4. 작별인사하기";
		
		int charNum = 0;
		int actionChoice = 0;
		
		while(true) {
			int i = 0;
			System.out.println(menuMsg);
			for (i = 0; i < animals.length; i++) {
				System.out.println(i + 1 + ". " + animals[i].name);
			}
			System.out.println(i +1 + ". 나가기");
			charNum = sc.nextInt();
			if(charNum == i + 1) {break;}
			
			while(true) {
				System.out.println(actionMsg);
				actionChoice = sc.nextInt();
				
				if(actionChoice == 4) {break;}
				
				switch(actionChoice) {
				case 1://먹기
					break;
				case 2://잠자기
					System.out.print("자는 중");
					for (int j = 0; j < 3; j++) {
						try {Thread.sleep(1000);} catch (InterruptedException e) {;}
						System.out.print(".");
					}
					System.out.println();
					animals[charNum - 1].sleep();
					System.out.println("잘 잤다! 생명이 1 증가했어요!");
					System.out.println(animals[charNum - 1].name + "의 생명 : " + animals[charNum - 1].life);
					break;
				case 3://산책하기
					break;
				}
			}
		}
		
	}
}


















